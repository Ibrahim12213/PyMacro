from windows import MainApp

if __name__ == "__main__":
    MainApp()
